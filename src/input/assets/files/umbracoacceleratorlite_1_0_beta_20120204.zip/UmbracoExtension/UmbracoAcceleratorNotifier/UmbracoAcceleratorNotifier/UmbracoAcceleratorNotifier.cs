﻿namespace UmbracoAcceleratorNotifier
{
    using System;
    using System.IO;
    using umbraco.BusinessLogic;
    using umbraco.IO;
    using umbraco.cms.businesslogic;
    using umbraco.cms.businesslogic.language;
    using umbraco.cms.businesslogic.macro;
    using umbraco.cms.businesslogic.media;
    using umbraco.cms.businesslogic.member;
    using umbraco.cms.businesslogic.packager;
    using umbraco.cms.businesslogic.template;
    using umbraco.cms.businesslogic.web;

    public class UmbracoAcceleratorNotifier : ApplicationBase
    {
        private const string AzureAcceleratorFileName = "UmbracoAcceleratorLite";
        private readonly string m_LocalAzureAcceleratorFileName = String.Format("/{0}.local", AzureAcceleratorFileName);

        public UmbracoAcceleratorNotifier()
        {
            CMSNode.AfterSave += CMSNode_AfterSave;
            Document.AfterSave += Document_AfterSave;
            CreatedPackage.AfterSave += CreatedPackage_AfterSave;
            Dictionary.DictionaryItem.Saving += Dictionary_AfterSave;
            DocumentType.AfterSave += DocumentType_AfterSave;
            Domain.AfterSave += Domain_AfterSave;
            InstalledPackage.AfterSave += InstalledPackage_AfterSave;
            Macro.AfterSave += Macro_AfterSave;
            Media.AfterSave += Media_AfterSave;
            MediaType.AfterSave += MediaType_AfterSave;
            Member.AfterSave += Member_AfterSave;
            MemberGroup.AfterSave += MemberGroup_AfterSave;
            MemberType.AfterSave += MemberType_AfterSave;
            Language.AfterSave += Language_AfterSave;
            StyleSheet.AfterSave += StyleSheet_AfterSave;
            StylesheetProperty.AfterSave += StylesheetProperty_AfterSave;
            Template.AfterSave += Template_AfterSave;
            User.Saving += User_AfterSave;
        }

        private void WriteUmbracoAcceleratorFile(int senderId, string module)
        {
            Log.Add(LogTypes.Save, senderId, String.Format("{0}: UmbracoAcceleratorNotifier", module));
            try
            {
                using (var sw = new StreamWriter(IOHelper.MapPath(m_LocalAzureAcceleratorFileName)))
                {
                    sw.WriteLine(DateTime.UtcNow);
                    Log.Add(LogTypes.Save, senderId, String.Format("{0}: UmbracoAcceleratorLite file written", module));
                }
            }
            catch (Exception)
            {
                Log.Add(LogTypes.Save, senderId, String.Format("{0}: unable to save UmbracoAcceleratorLite file", module));
            }
        }

        private void Document_AfterSave(Document sender, SaveEventArgs args)
        {
            WriteUmbracoAcceleratorFile(sender.Id, "Document_AfterSave");
        }

        private void CMSNode_AfterSave(object sender, SaveEventArgs e)
        {
            WriteUmbracoAcceleratorFile(0, "CMSNode_AfterSave");
        }

        private void StylesheetProperty_AfterSave(StylesheetProperty sender, SaveEventArgs e)
        {
            WriteUmbracoAcceleratorFile(sender.Id, "StylesheetProperty_AfterSave");
        }

        private void Language_AfterSave(Language sender, SaveEventArgs e)
        {
            WriteUmbracoAcceleratorFile(0, "Language_AfterSave");
        }

        private void Dictionary_AfterSave(Dictionary.DictionaryItem sender, EventArgs e)
        {
            WriteUmbracoAcceleratorFile(sender.id, "Dictionary_AfterSave");
        }

        private void User_AfterSave(User sender, EventArgs e)
        {
            WriteUmbracoAcceleratorFile(sender.Id, "User_AfterSave");
        }

        private void MemberType_AfterSave(MemberType sender, SaveEventArgs e)
        {
            WriteUmbracoAcceleratorFile(sender.Id, "MemberType_AfterSave");
        }

        private void MemberGroup_AfterSave(MemberGroup sender, SaveEventArgs e)
        {
            WriteUmbracoAcceleratorFile(sender.Id, "MemberGroup_AfterSave");
        }

        private void Member_AfterSave(Member sender, SaveEventArgs e)
        {
            WriteUmbracoAcceleratorFile(sender.Id, "Member_AfterSave");
        }

        private void MediaType_AfterSave(MediaType sender, SaveEventArgs e)
        {
            WriteUmbracoAcceleratorFile(sender.Id, "MediaType_AfterSave");
        }

        private void Media_AfterSave(Media sender, SaveEventArgs e)
        {
            WriteUmbracoAcceleratorFile(sender.Id, "Media_AfterSave");
        }

        private void Macro_AfterSave(Macro sender, SaveEventArgs e)
        {
            WriteUmbracoAcceleratorFile(sender.Id, "Macro_AfterSave");
        }

        private void InstalledPackage_AfterSave(InstalledPackage sender, EventArgs e)
        {
            WriteUmbracoAcceleratorFile(sender.Data.Id, "InstalledPackage_AfterSave");
        }

        private void Domain_AfterSave(Domain sender, SaveEventArgs e)
        {
            WriteUmbracoAcceleratorFile(sender.Id, "Domain_AfterSave");
        }

        private void DocumentType_AfterSave(DocumentType sender, SaveEventArgs e)
        {
            WriteUmbracoAcceleratorFile(sender.Id, "DocumentType_AfterSave");
        }

        private void CreatedPackage_AfterSave(CreatedPackage sender, SaveEventArgs e)
        {
            WriteUmbracoAcceleratorFile(sender.Data.Id, "CreatedPackage_AfterSave");
        }

        private void StyleSheet_AfterSave(StyleSheet sender, SaveEventArgs e)
        {
            WriteUmbracoAcceleratorFile(sender.Id, "StyleSheet_AfterSave");
        }

        private void Template_AfterSave(Template sender, SaveEventArgs e)
        {
            WriteUmbracoAcceleratorFile(sender.Id, "Template_AfterSave");
        }
    }
}
