CREATE CLUSTERED INDEX [ci_azure_fixup_dbo_umbracoUserLogins] ON [dbo].[umbracoUserLogins] 
(
	[userID] ASC
)WITH (STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF)
GO

/****** Object:  UmbracoAcceleratorLite helper table   Script Date: 01/15/2012 ******/
CREATE TABLE [dbo].[UmbracoAcceleratorLite](
	[SettingKey] [nvarchar](50) NOT NULL,
	[SettingValue] [nvarchar](50) NOT NULL,
 CONSTRAINT [PK_UmbracoAcceleratorLite] PRIMARY KEY CLUSTERED 
(
	[SettingKey] ASC
)WITH (STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF))
GO

/****** Object:  UmbracoAcceleratorLite helper table    Script Date: 01/15/2012 ******/
INSERT [dbo].[UmbracoAcceleratorLite] ([SettingKey], [SettingValue]) VALUES (N'LastBlobModification', N'')
GO