-- Please refer to: http://msdn.microsoft.com/en-us/library/ee336235.aspx

-- Connect to the master database and execute the following scripts:
CREATE LOGIN <login1> WITH password='<ProvidePassword>';
GO

CREATE USER <login1User> FROM LOGIN <login1>;
GO

EXEC sp_addrolemember 'dbmanager', '<login1User>';
EXEC sp_addrolemember 'loginmanager', '<login1User>';
GO
