﻿// UmbracoAcceleratorLite is based on the Windows Azure Accelerator for Umbraco
// project by Microsoft. Original project: http://waacceleratorumbraco.codeplex.com/
//
// Copyright (C) 2012 Gianni Rosa Gallina. All rights reserved.
//
// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

namespace DeploySite
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Windows.Forms;
    using DeployLibrary;

    public partial class UploadForm : Form
    {
        private const int DeleteWeight = 1024;
        private const string DefaultContainer = "sites";

        private readonly DeployConfigurationManager confmanager = new DeployConfigurationManager();
        private DeployConfiguration configuration;
        private Uploader uploader;
        private Downloader downloader;
        private long totalsize;
        private int blobstodelete;
        private int scale = 1;
        private readonly Dictionary<Control, bool> errorEnabled = new Dictionary<Control, bool>();
        private string containerName;

        public UploadForm() : this(string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, ".csproj .pdb .user", string.Empty)
        {
        }

        public UploadForm(string folderName, string containerName, string hostName, string storageAccountName, string storageAccountKey, string ignorePatterns, string dbConnectionString)
        {
            InitializeComponent();
            SetupDefaultValues(folderName, containerName, hostName, storageAccountName, storageAccountKey, ignorePatterns, dbConnectionString);
            SetupErrorProvider();
            LoadConfiguration();
            CheckIsValid();
            SetupToolTips();
        }

        public string ContainerName
        {
            get { return string.IsNullOrWhiteSpace(containerName) ? DefaultContainer : containerName; }
            set { containerName = value; }
        }

        private static bool IsEmpty(TextBox text)
        {
            return string.IsNullOrWhiteSpace(text.Text);
        }

        private static bool IsEmpty(ComboBox combo)
        {
            return string.IsNullOrWhiteSpace(combo.Text);
        }

        private void SetupDefaultValues(string folderName, string containerName, string hostName, string storageAccountName, string storageAccountKey, string ignorePatterns, string dbConnectionString)
        {
            ContainerName = containerName;

            cmbHostName.Text = hostName;
            txtPathToUpload.Text = folderName.EndsWith("\\") ? folderName.Substring(0, folderName.Length - 1) : folderName;
            txtStorageAccountName.Text = storageAccountName.ToLowerInvariant();
            txtStorageAccountKey.Text = storageAccountKey;
            txtIgnorePatterns.Text = ignorePatterns;
            txtDBConnectionString.Text = dbConnectionString;
        }

        private void SetupToolTips()
        {
            toolTip1 = new ToolTip(components);
            toolTip1.SetToolTip(cmbHostName, "The name of the site, which will be used to configure the host header in IIS.");
            toolTip1.SetToolTip(txtPathToUpload, "The path were the website you want to upload is located.");
            toolTip1.SetToolTip(txtStorageAccountName, "The name of the storage account that will be used for uploading the site.");
            toolTip1.SetToolTip(txtStorageAccountKey, "The primary or secondary keys used to access the storage account where the site will be uploaded.");
            toolTip1.SetToolTip(chkUpdateHostsFile, "Check if you want to edit the hosts file for resolving your site's address.");
            toolTip1.SetToolTip(chkCleanUpload, "Check if you want to perform a clean upload or just upload locally changed files");
            toolTip1.SetToolTip(txtIPAddress, "The IP address of your deployment. You can get it from http://windows.azure.com.");
            toolTip1.SetToolTip(txtIgnorePatterns, "Space-separated file extensions to be ignored locally when uploading the site");
            toolTip1.SetToolTip(txtDBConnectionString, "The connection string to the Umbraco's SQL Azure DB");
        }

        private void LoadConfiguration()
        {
            configuration = confmanager.GetConfiguration();

            if (configuration != null && configuration.Parameters != null)
            {
                cmbHostName.Items.Clear();

                foreach (DeployParameters parameter in configuration.Parameters)
                {
                    cmbHostName.Items.Add(parameter.HostName);
                }
            }
        }

        private void SetupErrorProvider()
        {
            errorProvider1.BlinkStyle = ErrorBlinkStyle.NeverBlink;
            SetupErrorProviderInControl(cmbHostName);
            SetupErrorProviderInControl(btnSelectFolder);
            SetupErrorProviderInControl(txtStorageAccountName);
            SetupErrorProviderInControl(txtStorageAccountKey);
            SetupErrorProviderInControl(txtIPAddress);
        }

        private void SetupErrorProviderInControl(Control control)
        {
            errorProvider1.SetIconPadding(control, 5);
            errorProvider1.SetIconAlignment(control, ErrorIconAlignment.MiddleRight);
            errorEnabled[control] = false;
        }

        private void CancelButtonClick(object sender, EventArgs e)
        {
            Close();
        }

        private void UploadButtonClick(object sender, EventArgs e)
        {
            try
            {
                if(rbtnUpload.Checked)
                    UploadProcess();
                else
                    DownloadProcess();
            }
            catch (Exception ex)
            {
                if (uploader != null)
                {
                    uploader.Stop();
                    uploader = null;
                }

                if (downloader != null)
                {
                    downloader.Stop();
                    downloader = null;
                }
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                ToDialog();
            }
        }

        private void DownloadProcess()
        {
            string hostName = cmbHostName.Text;
            string pathToUpload = txtPathToUpload.Text;
            string storageAccountName = txtStorageAccountName.Text.ToLowerInvariant();
            string storageAccountKey = txtStorageAccountKey.Text;
            string containerName = ContainerName;
            bool useDevelopmentStore = chkUseDevelopmentStorage.Checked;
            bool updateHostsFiles = chkUpdateHostsFile.Checked;
            bool cleanUpload = chkCleanUpload.Checked;
            string ignorePatterns = txtIgnorePatterns.Text;
            string ipaddress = txtIPAddress.Text;
            DateTime lastSyncDate = dateTimePicker1.Value;

            downloader = new Downloader(hostName, pathToUpload, useDevelopmentStore ? null : storageAccountName, useDevelopmentStore ? null : storageAccountKey, containerName, ignorePatterns, lastSyncDate);

            downloader.DownloadFile += FileOperation;
            downloader.DeleteFile += DeletingBlob;

            ToProcess();

            ICollection<string> files = downloader.GetCurrentLocalEntries();
            filestodelete = files.Count;

            ICollection<string> blobs = downloader.GetCurrentBlobs();
            totalsize = downloader.GetTotalSizeToDownload();
            
            PrepareProgressBar();

            if (files.Count > 0 && cleanUpload)
            {
                var confirm = new ConfirmProcess();
                DialogResult result = confirm.Process(useDevelopmentStore ? "DevStorage" : storageAccountName, hostName);

                if (result == DialogResult.Cancel)
                {
                    ToDialog();
                    return;
                }

                if (result == DialogResult.Retry)
                {
                    lblStatus.Text = "Deleting existing files";
                    downloader.DeleteCurrentFiles();
                }
                downloader.Run(false);
            }
            else
            {
                downloader.Run(true);
            }

            if (downloader.Stopped)
            {
                MessageBox.Show("Site Download Stopped", "Download Process");
            }
            else
            {
                prgProcess.Value = prgProcess.Maximum;
                prgProcess.Refresh();
                MessageBox.Show("Site Download Completed", "Download Process");

                var parameters = new DeployParameters
                {
                    HostName = hostName,
                    PathToUpload = pathToUpload,
                    UseDevelopmentStorage = useDevelopmentStore,
                    StorageAccountName = storageAccountName,
                    StorageAccountKey = storageAccountKey,
                    UpdateHostsFile = updateHostsFiles,
                    IPAddress = ipaddress,
                    IgnorePatterns = ignorePatterns,
                    CleanBeforeSync = cleanUpload,
                    IsUploadMode = rbtnUpload.Checked,
                    LastSyncUTC = dateTimePicker1.Value,
                    DBConnectionString = txtDBConnectionString.Text,
                };

                confmanager.SaveDeployParameters(configuration, parameters);
                LoadConfiguration();
            }

            SetupErrorProvider();
            ToDialog();
            downloader = null;
        }

        private void UploadProcess()
        {
            string hostName = cmbHostName.Text;
            string pathToUpload = txtPathToUpload.Text;
            string storageAccountName = txtStorageAccountName.Text.ToLowerInvariant();
            string storageAccountKey = txtStorageAccountKey.Text;
            string containerName = ContainerName;
            bool useDevelopmentStore = chkUseDevelopmentStorage.Checked;
            bool updateHostsFiles = chkUpdateHostsFile.Checked;
            bool cleanUpload = chkCleanUpload.Checked;
            string ignorePatterns = txtIgnorePatterns.Text;
            string ipaddress = txtIPAddress.Text;
            string connectionString = txtDBConnectionString.Text;

            uploader = new Uploader(hostName, pathToUpload, useDevelopmentStore ? null : storageAccountName, useDevelopmentStore ? null : storageAccountKey, containerName, ignorePatterns, connectionString);

            uploader.UploadFile += FileOperation;
            uploader.DeleteBlob += DeletingBlob;

            ToProcess();

            ICollection<string> blobs = uploader.GetCurrentBlobs();
            blobstodelete = blobs.Count;
            totalsize = uploader.GetTotalSizeToUpload();
            PrepareProgressBar();

            if (blobs.Count > 0 && cleanUpload)
            {
                var confirm = new ConfirmProcess();
                DialogResult result = confirm.Process(useDevelopmentStore ? "DevStorage" : storageAccountName, hostName);

                if (result == DialogResult.Cancel)
                {
                    ToDialog();
                    return;
                }

                if (result == DialogResult.Retry)
                {
                    lblStatus.Text = "Deleting existing blobs";
                    uploader.DeleteCurrentBlobs();
                }
                uploader.Run();
            }
            else
            {
                uploader.Sync();
            }

            if (uploader.Stopped)
            {
                MessageBox.Show("Site Upload Stopped", "Upload Process");
            }
            else
            {
                if (updateHostsFiles)
                {
                    HostsUpdater.UpdateDomain(hostName, ipaddress);
                }

                prgProcess.Value = prgProcess.Maximum;
                prgProcess.Refresh();
                MessageBox.Show("Site Upload Completed", "Upload Process");

                dateTimePicker1.Value = DateTime.UtcNow;

                var parameters = new DeployParameters {
                    HostName = hostName,
                    PathToUpload = pathToUpload,
                    UseDevelopmentStorage = useDevelopmentStore,
                    StorageAccountName = storageAccountName,
                    StorageAccountKey = storageAccountKey,
                    UpdateHostsFile = updateHostsFiles,
                    IPAddress = ipaddress,
                    IgnorePatterns = ignorePatterns,
                    CleanBeforeSync = cleanUpload,
                    IsUploadMode = rbtnUpload.Checked,
                    LastSyncUTC = dateTimePicker1.Value,
                    DBConnectionString = txtDBConnectionString.Text,
                };

                confmanager.SaveDeployParameters(configuration, parameters);
                LoadConfiguration();
            }

            SetupErrorProvider();
            ToDialog();
            uploader = null;
        }

        private void ToProcess()
        {
            cmbHostName.Enabled = false;
            txtPathToUpload.Enabled = false;
            txtStorageAccountName.Enabled = false;
            txtStorageAccountKey.Enabled = false;
            txtIgnorePatterns.Enabled = false;
            chkUseDevelopmentStorage.Enabled = false;
            chkCleanUpload.Enabled = false;
            chkUpdateHostsFile.Enabled = false;
            txtIPAddress.Enabled = false;
            btnUpload.Visible = false;
            btnCancel.Visible = false;
            prgProcess.Value = 0;
            prgProcess.Visible = true;
            btnSelectFolder.Enabled = false;
            lblStatus.Text = string.Empty;
            lblStatus.Visible = true;
            btnStop.Top = btnCancel.Top;
            btnStop.Left = btnCancel.Left;
            btnStop.Visible = true;
            dateTimePicker1.Enabled = false;
            txtDBConnectionString.Enabled = false;
            Refresh();
        }

        private void ToDialog()
        {
            cmbHostName.Enabled = true;
            txtPathToUpload.Enabled = true;
            txtIgnorePatterns.Enabled = true;
            chkUseDevelopmentStorage.Enabled = true;

            if (chkUseDevelopmentStorage.Checked)
            {
                txtStorageAccountName.Enabled = false;
                txtStorageAccountKey.Enabled = false;
            }
            else
            {
                txtStorageAccountName.Enabled = true;
                txtStorageAccountKey.Enabled = true;
            }

            if (chkUpdateHostsFile.Checked)
            {
                txtIPAddress.Enabled = true;
            }
            else
            {
                txtIPAddress.Enabled = false;
            }

            chkCleanUpload.Enabled = true;
            chkUpdateHostsFile.Enabled = true;
            btnSelectFolder.Enabled = true;
            prgProcess.Visible = false;
            btnStop.Visible = false;
            lblStatus.Visible = false;
            btnUpload.Visible = true;
            btnCancel.Visible = true;
            dateTimePicker1.Enabled = true;
            txtDBConnectionString.Enabled = true;

            Refresh();
        }

        private void SelectFolderButtonClick(object sender, EventArgs e)
        {
            if (folderToUploadDialog.ShowDialog() != DialogResult.OK)
            {
                return;
            }

            txtPathToUpload.Text = folderToUploadDialog.SelectedPath;
            errorEnabled[txtPathToUpload] = true;
            CheckIsValid();
        }

        private void PrepareProgressBar()
        {
            prgProcess.Value = 0;

            scale = 1;

            long size = totalsize;

            while (size > int.MaxValue)
            {
                scale *= 1024;
                size /= 1024;
            }

            prgProcess.Maximum = (int)size + blobstodelete * DeleteWeight;
        }

        private void DeletingBlob(string message)
        {
            lblStatus.Text = string.Format("Deleting {0}: {1}", rbtnUpload.Checked ? "blob" : "file", message);
            lblStatus.Refresh();

            if (prgProcess.Value < prgProcess.Maximum)
            {
                prgProcess.Value += DeleteWeight;
                prgProcess.Refresh();
            }
        }

        private void FileOperation(string message, long size)
        {
            lblStatus.Text = string.Format("{0} blob: {1}", rbtnUpload.Checked ? "Uploading" : "Downloading" ,message);
            lblStatus.Refresh();

            var update = (int)(size / scale);

            if (prgProcess.Value + update < prgProcess.Maximum)
            {
                prgProcess.Value += update;
            }
            else
            {
                prgProcess.Value = prgProcess.Maximum;
            }

            prgProcess.Update();

            Application.DoEvents();
        }

        private void UseDevelopmentStorageCheckedChanged(object sender, EventArgs e)
        {
            if (chkUseDevelopmentStorage.Checked)
            {
                txtStorageAccountName.Enabled = false;
                txtStorageAccountKey.Enabled = false;
            }
            else
            {
                txtStorageAccountName.Enabled = true;
                txtStorageAccountKey.Enabled = true;
            }

            errorEnabled[txtStorageAccountName] = false;
            errorEnabled[txtStorageAccountKey] = false;

            CheckIsValid();
        }

        private void StopButtonClick(object sender, EventArgs e)
        {
            if (uploader != null)
            {
                uploader.Stop();
            }
        }

        private bool IsValid()
        {
            bool isValid = true;

            if (IsEmpty(cmbHostName))
            {
                SetError(cmbHostName, "Host name cannot be blank");
                isValid = false;
            }
            else if (!Validations.IsValidDomainName(cmbHostName.Text))
            {
                SetError(cmbHostName, "Host name is not valid");
                isValid = false;
            }
            else
            {
                SetError(cmbHostName, string.Empty);
            }

            if (IsEmpty(txtPathToUpload))
            {
                SetError(btnSelectFolder, "Path cannot be blank");
                isValid = false;
            }
            else if (!Directory.Exists(txtPathToUpload.Text))
            {
                SetError(btnSelectFolder, "Path doesn't exist");
                isValid = false;
            }
            else
            {
                SetError(btnSelectFolder, string.Empty);
            }

            if (!chkUseDevelopmentStorage.Checked)
            {
                if (IsEmpty(txtStorageAccountName))
                {
                    SetError(txtStorageAccountName, "Storage Account Name cannot be blank");
                    isValid = false;
                }
                else
                {
                    SetError(txtStorageAccountName, string.Empty);
                }

                if (IsEmpty(txtStorageAccountKey))
                {
                    SetError(txtStorageAccountKey, "Storage Account Key cannot be blank");
                    isValid = false;
                }
                else
                {
                    SetError(txtStorageAccountKey, string.Empty);
                }
            }
            else
            {
                SetError(txtStorageAccountName, string.Empty);
                SetError(txtStorageAccountKey, string.Empty);
            }

            if (chkUpdateHostsFile.Checked)
            {
                if (IsEmpty(txtIPAddress))
                {
                    SetError(txtIPAddress, "IP Address cannot be blank");
                    isValid = false;
                }
                else if (!Validations.IsValidIPAddress(txtIPAddress.Text))
                {
                    SetError(txtIPAddress, "Invalid IP Address");
                    isValid = false;
                }
                else
                {
                    SetError(txtIPAddress, string.Empty);
                }
            }
            else
            {
                SetError(txtIPAddress, string.Empty);
            }

            return isValid;
        }

        private void CheckIsValid()
        {
            btnUpload.Enabled = IsValid();
        }

        private void PathToUploadTextChanged(object sender, EventArgs e)
        {
            CheckIsValid();
        }

        private void StorageAccountNameTextChanged(object sender, EventArgs e)
        {
            CheckIsValid();
        }

        private void StorageAccountKeyTextChanged(object sender, EventArgs e)
        {
            CheckIsValid();
        }

        private void UpdateHostsFileCheckedChanged(object sender, EventArgs e)
        {
            if (chkUpdateHostsFile.Checked)
            {
                txtIPAddress.Enabled = true;
            }
            else
            {
                txtIPAddress.Enabled = false;
            }

            CheckIsValid();
        }

        private void SetError(Control control, string message)
        {
            if (errorEnabled.ContainsKey(control) && errorEnabled[control])
            {
                errorProvider1.SetError(control, message);
            }
            else
            {
                errorProvider1.SetError(control, string.Empty);
            }
        }

        private void PathToUploadLeave(object sender, EventArgs e)
        {
            CheckIsValid();
        }

        private void StorageAccountNameLeave(object sender, EventArgs e)
        {
            errorEnabled[txtStorageAccountKey] = true;
            CheckIsValid();
        }

        private void StorageAccountKeyLeave(object sender, EventArgs e)
        {
            errorEnabled[txtStorageAccountName] = true;
            CheckIsValid();
        }

        private void IPAddressLeave(object sender, EventArgs e)
        {
            errorEnabled[txtIPAddress] = true;
            CheckIsValid();
        }

        private void SelectFolderLeave(object sender, EventArgs e)
        {
            errorEnabled[btnSelectFolder] = true;
            CheckIsValid();
        }

        private void IPAddressTextChanged(object sender, EventArgs e)
        {
            CheckIsValid();
        }

        private void HostNameSelectedIndexChanged(object sender, EventArgs e)
        {
            string hostName = cmbHostName.Text;

            if (!string.IsNullOrWhiteSpace(hostName))
            {
                DeployParameters parameters = confmanager.GetDeployParametersByHostName(configuration, hostName);

                if (parameters != null)
                {
                    txtPathToUpload.Text = parameters.PathToUpload;
                    chkUseDevelopmentStorage.Checked = parameters.UseDevelopmentStorage;
                    txtStorageAccountName.Text = parameters.StorageAccountName.ToLowerInvariant();
                    txtStorageAccountKey.Text = parameters.StorageAccountKey;
                    chkUpdateHostsFile.Checked = parameters.UpdateHostsFile;
                    txtIPAddress.Text = parameters.IPAddress;
                    txtIgnorePatterns.Text = parameters.IgnorePatterns;
                    rbtnUpload.Checked = parameters.IsUploadMode;
                    rbtnDownload.Checked = !parameters.IsUploadMode;
                    dateTimePicker1.Value = parameters.LastSyncUTC > DateTime.MinValue ? parameters.LastSyncUTC : DateTime.UtcNow;
                    chkCleanUpload.Checked = parameters.CleanBeforeSync;
                    txtDBConnectionString.Text = parameters.DBConnectionString;
                    ToDialog();
                }
            }
        }

        private void HostNameLeave(object sender, EventArgs e)
        {
            errorEnabled[cmbHostName] = true;
            CheckIsValid();
        }

        private void HostNameTextChanged(object sender, EventArgs e)
        {
            CheckIsValid();
        }

        public int filestodelete { get; set; }
    }
}

