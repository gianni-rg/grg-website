﻿// UmbracoAcceleratorLite is based on the Windows Azure Accelerator for Umbraco
// project by Microsoft. Original project: http://waacceleratorumbraco.codeplex.com/
//
// Copyright (C) 2012 Gianni Rosa Gallina. All rights reserved.
//
// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

namespace DeploySite
{
    partial class UploadForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtPathToUpload;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtStorageAccountName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtStorageAccountKey;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox chkUpdateHostsFile;
        private System.Windows.Forms.Button btnUpload;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSelectFolder;
        private System.Windows.Forms.FolderBrowserDialog folderToUploadDialog;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.ProgressBar prgProcess;
        private System.Windows.Forms.CheckBox chkUseDevelopmentStorage;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.TextBox txtIPAddress;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ComboBox cmbHostName;
        private System.Windows.Forms.ToolTip toolTip1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UploadForm));
            this.label1 = new System.Windows.Forms.Label();
            this.txtPathToUpload = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtStorageAccountName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtStorageAccountKey = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.chkUpdateHostsFile = new System.Windows.Forms.CheckBox();
            this.btnUpload = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSelectFolder = new System.Windows.Forms.Button();
            this.folderToUploadDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.lblStatus = new System.Windows.Forms.Label();
            this.prgProcess = new System.Windows.Forms.ProgressBar();
            this.chkUseDevelopmentStorage = new System.Windows.Forms.CheckBox();
            this.btnStop = new System.Windows.Forms.Button();
            this.txtIPAddress = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.cmbHostName = new System.Windows.Forms.ComboBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.chkCleanUpload = new System.Windows.Forms.CheckBox();
            this.txtIgnorePatterns = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.rbtnUpload = new System.Windows.Forms.RadioButton();
            this.rbtnDownload = new System.Windows.Forms.RadioButton();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtDBConnectionString = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(10, 120);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(290, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Domain Name (e.g. www.contoso.com)";
            // 
            // txtPathToUpload
            // 
            this.txtPathToUpload.Font = new System.Drawing.Font("Tahoma", 9.5F);
            this.txtPathToUpload.Location = new System.Drawing.Point(13, 208);
            this.txtPathToUpload.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtPathToUpload.Name = "txtPathToUpload";
            this.txtPathToUpload.Size = new System.Drawing.Size(645, 27);
            this.txtPathToUpload.TabIndex = 3;
            this.txtPathToUpload.TextChanged += new System.EventHandler(this.PathToUploadTextChanged);
            this.txtPathToUpload.Leave += new System.EventHandler(this.PathToUploadLeave);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9.25F);
            this.label2.Location = new System.Drawing.Point(10, 181);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(137, 19);
            this.label2.TabIndex = 2;
            this.label2.Text = "Content to Deploy";
            // 
            // txtStorageAccountName
            // 
            this.txtStorageAccountName.Font = new System.Drawing.Font("Tahoma", 9.5F);
            this.txtStorageAccountName.Location = new System.Drawing.Point(13, 279);
            this.txtStorageAccountName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtStorageAccountName.Name = "txtStorageAccountName";
            this.txtStorageAccountName.Size = new System.Drawing.Size(270, 27);
            this.txtStorageAccountName.TabIndex = 5;
            this.txtStorageAccountName.TextChanged += new System.EventHandler(this.StorageAccountNameTextChanged);
            this.txtStorageAccountName.Leave += new System.EventHandler(this.StorageAccountNameLeave);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9.25F);
            this.label3.Location = new System.Drawing.Point(10, 248);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(171, 19);
            this.label3.TabIndex = 4;
            this.label3.Text = "Storage Account Name";
            // 
            // txtStorageAccountKey
            // 
            this.txtStorageAccountKey.Font = new System.Drawing.Font("Tahoma", 9.5F);
            this.txtStorageAccountKey.Location = new System.Drawing.Point(13, 349);
            this.txtStorageAccountKey.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtStorageAccountKey.Name = "txtStorageAccountKey";
            this.txtStorageAccountKey.Size = new System.Drawing.Size(681, 27);
            this.txtStorageAccountKey.TabIndex = 7;
            this.txtStorageAccountKey.TextChanged += new System.EventHandler(this.StorageAccountKeyTextChanged);
            this.txtStorageAccountKey.Leave += new System.EventHandler(this.StorageAccountKeyLeave);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9.25F);
            this.label4.Location = new System.Drawing.Point(10, 318);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(155, 19);
            this.label4.TabIndex = 6;
            this.label4.Text = "Storage Account Key";
            // 
            // chkUpdateHostsFile
            // 
            this.chkUpdateHostsFile.AutoSize = true;
            this.chkUpdateHostsFile.Font = new System.Drawing.Font("Tahoma", 9.25F);
            this.chkUpdateHostsFile.Location = new System.Drawing.Point(12, 468);
            this.chkUpdateHostsFile.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkUpdateHostsFile.Name = "chkUpdateHostsFile";
            this.chkUpdateHostsFile.Size = new System.Drawing.Size(697, 23);
            this.chkUpdateHostsFile.TabIndex = 8;
            this.chkUpdateHostsFile.Text = "Update the Hosts File on your local machine for testing purposes (You must be Adm" +
    "inistrator)";
            this.chkUpdateHostsFile.UseVisualStyleBackColor = true;
            this.chkUpdateHostsFile.CheckedChanged += new System.EventHandler(this.UpdateHostsFileCheckedChanged);
            // 
            // btnUpload
            // 
            this.btnUpload.Font = new System.Drawing.Font("Tahoma", 9.25F);
            this.btnUpload.Location = new System.Drawing.Point(450, 36);
            this.btnUpload.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnUpload.Name = "btnUpload";
            this.btnUpload.Size = new System.Drawing.Size(121, 28);
            this.btnUpload.TabIndex = 9;
            this.btnUpload.Text = "Upload";
            this.btnUpload.UseVisualStyleBackColor = true;
            this.btnUpload.Click += new System.EventHandler(this.UploadButtonClick);
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Font = new System.Drawing.Font("Tahoma", 9.25F);
            this.btnCancel.Location = new System.Drawing.Point(579, 36);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(121, 28);
            this.btnCancel.TabIndex = 10;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.CancelButtonClick);
            // 
            // btnSelectFolder
            // 
            this.btnSelectFolder.Location = new System.Drawing.Point(664, 208);
            this.btnSelectFolder.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSelectFolder.Name = "btnSelectFolder";
            this.btnSelectFolder.Size = new System.Drawing.Size(30, 25);
            this.btnSelectFolder.TabIndex = 4;
            this.btnSelectFolder.Text = "...";
            this.btnSelectFolder.UseVisualStyleBackColor = true;
            this.btnSelectFolder.Click += new System.EventHandler(this.SelectFolderButtonClick);
            this.btnSelectFolder.Leave += new System.EventHandler(this.SelectFolderLeave);
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.BackColor = System.Drawing.Color.Transparent;
            this.lblStatus.Location = new System.Drawing.Point(14, 12);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(0, 19);
            this.lblStatus.TabIndex = 11;
            this.lblStatus.Visible = false;
            // 
            // prgProcess
            // 
            this.prgProcess.Location = new System.Drawing.Point(14, 36);
            this.prgProcess.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.prgProcess.Name = "prgProcess";
            this.prgProcess.Size = new System.Drawing.Size(558, 28);
            this.prgProcess.TabIndex = 12;
            this.prgProcess.Visible = false;
            // 
            // chkUseDevelopmentStorage
            // 
            this.chkUseDevelopmentStorage.AutoSize = true;
            this.chkUseDevelopmentStorage.Font = new System.Drawing.Font("Tahoma", 9.25F);
            this.chkUseDevelopmentStorage.Location = new System.Drawing.Point(184, 248);
            this.chkUseDevelopmentStorage.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkUseDevelopmentStorage.Name = "chkUseDevelopmentStorage";
            this.chkUseDevelopmentStorage.Size = new System.Drawing.Size(214, 23);
            this.chkUseDevelopmentStorage.TabIndex = 5;
            this.chkUseDevelopmentStorage.Text = "Use Development Storage";
            this.chkUseDevelopmentStorage.UseVisualStyleBackColor = true;
            this.chkUseDevelopmentStorage.CheckedChanged += new System.EventHandler(this.UseDevelopmentStorageCheckedChanged);
            // 
            // btnStop
            // 
            this.btnStop.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnStop.Font = new System.Drawing.Font("Tahoma", 9.25F);
            this.btnStop.Location = new System.Drawing.Point(577, 0);
            this.btnStop.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(121, 28);
            this.btnStop.TabIndex = 13;
            this.btnStop.Text = "Stop";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Visible = false;
            this.btnStop.Click += new System.EventHandler(this.StopButtonClick);
            // 
            // txtIPAddress
            // 
            this.txtIPAddress.Enabled = false;
            this.txtIPAddress.Font = new System.Drawing.Font("Tahoma", 9.5F);
            this.txtIPAddress.Location = new System.Drawing.Point(107, 496);
            this.txtIPAddress.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtIPAddress.Name = "txtIPAddress";
            this.txtIPAddress.Size = new System.Drawing.Size(209, 27);
            this.txtIPAddress.TabIndex = 10;
            this.txtIPAddress.TextChanged += new System.EventHandler(this.IPAddressTextChanged);
            this.txtIPAddress.Leave += new System.EventHandler(this.IPAddressLeave);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 9.25F);
            this.label5.Location = new System.Drawing.Point(9, 500);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 19);
            this.label5.TabIndex = 9;
            this.label5.Text = "IP Address:";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Window;
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.btnStop);
            this.panel1.Controls.Add(this.prgProcess);
            this.panel1.Controls.Add(this.btnUpload);
            this.panel1.Controls.Add(this.btnCancel);
            this.panel1.Controls.Add(this.lblStatus);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 547);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(719, 73);
            this.panel1.TabIndex = 14;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(719, 1);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // cmbHostName
            // 
            this.cmbHostName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbHostName.FormattingEnabled = true;
            this.cmbHostName.Location = new System.Drawing.Point(13, 142);
            this.cmbHostName.Name = "cmbHostName";
            this.cmbHostName.Size = new System.Drawing.Size(270, 27);
            this.cmbHostName.TabIndex = 1;
            this.cmbHostName.SelectedIndexChanged += new System.EventHandler(this.HostNameSelectedIndexChanged);
            this.cmbHostName.TextChanged += new System.EventHandler(this.HostNameTextChanged);
            this.cmbHostName.Leave += new System.EventHandler(this.HostNameLeave);
            // 
            // chkCleanUpload
            // 
            this.chkCleanUpload.AutoSize = true;
            this.chkCleanUpload.Font = new System.Drawing.Font("Tahoma", 9.25F);
            this.chkCleanUpload.Location = new System.Drawing.Point(10, 57);
            this.chkCleanUpload.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkCleanUpload.Name = "chkCleanUpload";
            this.chkCleanUpload.Size = new System.Drawing.Size(156, 23);
            this.chkCleanUpload.TabIndex = 16;
            this.chkCleanUpload.Text = "Clean before sync";
            this.chkCleanUpload.UseVisualStyleBackColor = true;
            // 
            // txtIgnorePatterns
            // 
            this.txtIgnorePatterns.Font = new System.Drawing.Font("Tahoma", 9.5F);
            this.txtIgnorePatterns.Location = new System.Drawing.Point(302, 53);
            this.txtIgnorePatterns.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtIgnorePatterns.Name = "txtIgnorePatterns";
            this.txtIgnorePatterns.Size = new System.Drawing.Size(251, 27);
            this.txtIgnorePatterns.TabIndex = 17;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 9.25F);
            this.label6.Location = new System.Drawing.Point(172, 57);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(124, 19);
            this.label6.TabIndex = 18;
            this.label6.Text = "Ignore patterns:";
            // 
            // rbtnUpload
            // 
            this.rbtnUpload.AutoSize = true;
            this.rbtnUpload.Checked = true;
            this.rbtnUpload.Location = new System.Drawing.Point(10, 26);
            this.rbtnUpload.Name = "rbtnUpload";
            this.rbtnUpload.Size = new System.Drawing.Size(74, 21);
            this.rbtnUpload.TabIndex = 19;
            this.rbtnUpload.TabStop = true;
            this.rbtnUpload.Text = "Upload";
            this.rbtnUpload.UseVisualStyleBackColor = true;
            // 
            // rbtnDownload
            // 
            this.rbtnDownload.AutoSize = true;
            this.rbtnDownload.Location = new System.Drawing.Point(10, 55);
            this.rbtnDownload.Name = "rbtnDownload";
            this.rbtnDownload.Size = new System.Drawing.Size(91, 21);
            this.rbtnDownload.TabIndex = 20;
            this.rbtnDownload.Text = "Download";
            this.rbtnDownload.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "ddMMMMyyyy - HH:mm:ss";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(174, 22);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(257, 27);
            this.dateTimePicker1.TabIndex = 21;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbtnUpload);
            this.groupBox1.Controls.Add(this.rbtnDownload);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(123, 91);
            this.groupBox1.TabIndex = 22;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Mode";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.chkCleanUpload);
            this.groupBox2.Controls.Add(this.txtIgnorePatterns);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.dateTimePicker1);
            this.groupBox2.Location = new System.Drawing.Point(141, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(566, 91);
            this.groupBox2.TabIndex = 23;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Synchronization settings";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 9.25F);
            this.label7.Location = new System.Drawing.Point(6, 23);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(162, 19);
            this.label7.TabIndex = 19;
            this.label7.Text = "Last sync date (UTC):";
            // 
            // txtDBConnectionString
            // 
            this.txtDBConnectionString.Font = new System.Drawing.Font("Tahoma", 9.5F);
            this.txtDBConnectionString.Location = new System.Drawing.Point(17, 422);
            this.txtDBConnectionString.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtDBConnectionString.Name = "txtDBConnectionString";
            this.txtDBConnectionString.Size = new System.Drawing.Size(681, 27);
            this.txtDBConnectionString.TabIndex = 25;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 9.25F);
            this.label8.Location = new System.Drawing.Point(14, 391);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(240, 19);
            this.label8.TabIndex = 24;
            this.label8.Text = "SQL Azure DB Connection String";
            // 
            // UploadForm
            // 
            this.AcceptButton = this.btnUpload;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(242)))), ((int)(((byte)(244)))));
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(719, 620);
            this.Controls.Add(this.txtDBConnectionString);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cmbHostName);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtIPAddress);
            this.Controls.Add(this.chkUseDevelopmentStorage);
            this.Controls.Add(this.btnSelectFolder);
            this.Controls.Add(this.chkUpdateHostsFile);
            this.Controls.Add(this.txtStorageAccountKey);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtStorageAccountName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtPathToUpload);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Tahoma", 9.5F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "UploadForm";
            this.Text = "Deploy Web Site to Windows Azure Blob Storage";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox chkCleanUpload;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtIgnorePatterns;
        private System.Windows.Forms.RadioButton rbtnDownload;
        private System.Windows.Forms.RadioButton rbtnUpload;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtDBConnectionString;
        private System.Windows.Forms.Label label8;
    }
}

