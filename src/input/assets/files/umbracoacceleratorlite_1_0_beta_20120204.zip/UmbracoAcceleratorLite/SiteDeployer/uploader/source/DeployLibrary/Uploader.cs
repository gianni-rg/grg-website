﻿// UmbracoAcceleratorLite is based on the Windows Azure Accelerator for Umbraco
// project by Microsoft. Original project: http://waacceleratorumbraco.codeplex.com/
//
// Copyright (C) 2012 Gianni Rosa Gallina. All rights reserved.
//
// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

namespace DeployLibrary
{
    using System;
    using System.Collections.Generic;
    using System.Data.SqlClient;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using Microsoft.WindowsAzure;
    using Microsoft.WindowsAzure.StorageClient;

    public class Uploader
    {
        // UmbracoAcceleratorLite
        private const string AzureAcceleratorFileName = "UmbracoAcceleratorLite";
        private Dictionary<string, Entry> m_Entries;
        private readonly HashSet<string> m_PatternToBeIgnored;
        private readonly CloudBlobContainer m_Container;

        private readonly string hostName;
        private readonly string pathToUpload;
        private readonly string storageAccountName;
        private readonly string storageAccountKey;
        private readonly string containerName;

        private readonly string m_DBConnectionString;
        private CultureInfo m_CurrentEnCulture;

        public Uploader(string hostName, string pathToUpload, string storageAccountName, string storageAccountKey, string containerName, string ignorePatterns, string dbConnectionString)
        {
            this.hostName = hostName;
            this.pathToUpload = pathToUpload;
            this.storageAccountName = storageAccountName;
            this.storageAccountKey = storageAccountKey;
            this.containerName = containerName;

            // UmbracoAcceleratorLite
            m_DBConnectionString = dbConnectionString;
            m_CurrentEnCulture = CultureInfo.CreateSpecificCulture("en-US");
            m_Container = GetContainer();
            m_PatternToBeIgnored = new HashSet<string>();
            string[] patternToIgnore = ignorePatterns.Split(' ');
            foreach (string p in patternToIgnore)
            {
                m_PatternToBeIgnored.Add(p.ToLower());
            }
        }

        public delegate void MessageHandler(string message, long size);

        public delegate void DeleteBlobHandler(string message);

        public delegate void CountHandler(int count, long totalSize);

        public event CountHandler UploadCount;

        public event MessageHandler UploadFile;

        public event DeleteBlobHandler DeleteBlob;

        public event MessageHandler CreateDirectory;

        public bool Stopped { get; set; }

        public void Run()
        {
            // UmbracoAcceleratorLite optimization
            CloudBlobContainer container = m_Container;

            CloudBlob hostBlob = container.GetBlobReference(hostName);
            hostBlob.Metadata["IsDirectory"] = "true";
            hostBlob.UploadByteArray(new byte[0]);

            // UmbracoAcceleratorLite: added ToList() for optimization
            List<Tuple<string, Entry>> things = EnumerateEntries(pathToUpload).ToList();
            long totalLength = things.Sum(t => t.Item2.Length);
            int count = things.Count();

            if (UploadCount != null)
            {
                UploadCount(count, totalLength);
            }

            foreach (var thing in things)
            {
                if (Stopped)
                {
                    break;
                }

                string path = thing.Item1;
                string blobPath = string.Format("{0}/{1}", hostName, path);
                Entry entry = thing.Item2;
                CloudBlob newBlob = container.GetBlobReference(blobPath);

                if (entry.IsDirectory)
                {
                    if (CreateDirectory != null)
                    {
                        CreateDirectory(blobPath, 0);
                    }

                    newBlob.Metadata["IsDirectory"] = "true";
                    newBlob.UploadByteArray(new byte[0]);
                }
                else
                {
                    if (UploadFile != null)
                    {
                        int pos = blobPath.IndexOf('/');
                        string name = blobPath;

                        if (pos > 0)
                        {
                            name = blobPath.Substring(pos + 1);
                        }

                        UploadFile(name, entry.Length);
                    }

                    newBlob.UploadFile(Path.Combine(pathToUpload, path));
                }
            }
            UpdateCloudLastModification();
        }

        // UmbracoAcceleratorLite
        public void Sync()
        {
            CloudBlobContainer container = m_Container;

            List<Tuple<string, Entry>> things = EnumerateEntries(pathToUpload).ToList();
            long totalLength = things.Sum(t => t.Item2.Length);
            int count = things.Count();

            if (UploadCount != null)
            {
                UploadCount(count, totalLength);
            }

            var seen = new HashSet<string>();

            foreach (var thing in things)
            {
                if (Stopped)
                {
                    break;
                }

                string path = thing.Item1;
                Entry entry = thing.Item2;

                string blobPath = string.Format("{0}/{1}", hostName, path);

                // Mark the entry as "still existing". If an entry is not added to the set,
                // it means that it has been deleted locally. Later, it will be deleted on the
                // blob storage.
                seen.Add(blobPath);

                // Don't sync directories
                if (entry.IsDirectory)
                {
                    continue;
                }

                // Current entry is new or changed
                if (!m_Entries.ContainsKey(blobPath) || m_Entries[blobPath].CloudLastModified < entry.LocalLastModified)
                {
                    CloudBlob newBlob = container.GetBlobReference(blobPath);
                    if (entry.IsDirectory)
                    {
                        if (CreateDirectory != null)
                        {
                            CreateDirectory(blobPath, 0);
                        }

                        newBlob.Metadata["IsDirectory"] = "true";
                        newBlob.UploadByteArray(new byte[0]);
                    }
                    else
                    {
                        if (UploadFile != null)
                        {
                            int pos = blobPath.IndexOf('/');
                            string name = blobPath;

                            if (pos > 0)
                            {
                                name = blobPath.Substring(pos + 1);
                            }

                            UploadFile(name, entry.Length);
                        }
                        newBlob.UploadFile(Path.Combine(pathToUpload, path));
                    }

                    entry.CloudLastModified = newBlob.Properties.LastModifiedUtc;
                    m_Entries[blobPath] = entry;
                }
            }

            // For each local deleted files, delete it on the blob storage
            foreach (var entry in m_Entries.Where(k => !k.Value.IsDirectory && !seen.Contains(k.Key)).ToArray())
            {
                if (string.IsNullOrEmpty(Path.GetDirectoryName(entry.Key)) && Path.GetExtension(entry.Key).ToLowerInvariant() == ".pfx")
                {
                    // leave these alone
                    continue;
                }

                try
                {
                    container.GetBlobReference(entry.Key).Delete();
                }
                catch
                {
                    // ignore if the blob's already gone
                }

                m_Entries.Remove(entry.Key);
            }
            UpdateCloudLastModification();
        }

        private bool HasToBeIgnored(string pattern)
        {
            return m_PatternToBeIgnored.Any(pattern.Contains);
        }

        public void Stop()
        {
            Stopped = true;
        }

        public ICollection<string> GetCurrentBlobs()
        {
            //UmbracoAcceleratorLite
            m_Entries = new Dictionary<string, Entry>();

            // UmbracoAcceleratorLite optimization
            CloudBlobContainer container = m_Container;

            int prefixLength = container.Uri.ToString().Length;
            IList<string> blobs = new List<string>();

            List<CloudBlob> cloudBlobs = container.ListBlobs(new BlobRequestOptions {
                UseFlatBlobListing = true,
                BlobListingDetails = BlobListingDetails.Metadata
            }).OfType<CloudBlob>().ToList();

            foreach (CloudBlob blob in cloudBlobs)
            {
                string path = blob.Uri.ToString().Substring(prefixLength + 1);

                if (path.Equals(hostName, StringComparison.OrdinalIgnoreCase) || path.StartsWith(String.Format("{0}/", hostName), StringComparison.OrdinalIgnoreCase))
                {
                    blobs.Add(path);

                    // UmbracoAcceleratorLite
                    var entry = new Entry {
                        IsDirectory = blob.Metadata["IsDirectory"] == "true",
                        CloudLastModified = blob.Properties.LastModifiedUtc,
                        SiteName = path.Split('/').First()
                    };

                    if (!m_Entries.ContainsKey(path) || m_Entries[path].CloudLastModified < entry.CloudLastModified)
                    {
                        m_Entries[path] = entry;
                    }
                }
            }

            return blobs;
        }

        public void DeleteCurrentBlobs()
        {
            // UmbracoAcceleratorLite optimization
            CloudBlobContainer container = m_Container;

            foreach (string blobpath in GetCurrentBlobs())
            {
                if (DeleteBlob != null)
                {
                    DeleteBlob(blobpath);
                }

                CloudBlob blob = container.GetBlobReference(blobpath);
                blob.DeleteIfExists();
            }
        }

        public long GetTotalSizeToUpload()
        {
            IEnumerable<Tuple<string, Entry>> things = EnumerateEntries(pathToUpload);

            return things.Sum(t => t.Item2.Length);
        }

        private IEnumerable<Tuple<string, Entry>> EnumerateEntries(string path)
        {
            foreach (string directory in Directory.EnumerateFileSystemEntries(path, "*", SearchOption.AllDirectories))
            {
                string relativePath = directory.Substring(path.Length + 1).Replace('\\', '/');

                // UmbracoAcceleratorLite: ignore app_data/ content, obj/ content, AzureAcceleratorEx files and user-specified file extensions
                string relativePathLower = relativePath.ToLowerInvariant();
                if (relativePathLower.StartsWith(@"app_data") || relativePathLower.StartsWith(@"obj/") || relativePath.Contains(AzureAcceleratorFileName) || HasToBeIgnored(relativePathLower))
                {
                    continue;
                }

                var info = new FileInfo(directory);
                var entry = new Entry {
                    LocalLastModified = info.LastWriteTimeUtc,
                    IsDirectory = info.Attributes.HasFlag(FileAttributes.Directory),
                    Length = info.Attributes.HasFlag(FileAttributes.Directory) ? 0 : info.Length,
                    SiteName = hostName
                };

                yield return new Tuple<string, Entry>(relativePath, entry);
            }
        }

        private CloudBlobContainer GetContainer()
        {
            CloudStorageAccount account;

            if (storageAccountKey == null)
            {
                account = CloudStorageAccount.DevelopmentStorageAccount;
            }
            else
            {
                string storageConnectionString = string.Format("DefaultEndpointsProtocol=https;AccountName={0};AccountKey={1}", storageAccountName, storageAccountKey);
                account = CloudStorageAccount.Parse(storageConnectionString);
            }

            CloudBlobContainer container = account.CreateCloudBlobClient().GetContainerReference(containerName);
            container.CreateIfNotExist();

            return container;
        }

        private void UpdateCloudLastModification()
        {

            DateTime currentTimestamp = DateTime.UtcNow;
            using (var cn = new SqlConnection(m_DBConnectionString))
            {
                cn.Open();

                var cmd = new SqlCommand {
                    Connection = cn,
                    CommandText = String.Format("UPDATE UmbracoAcceleratorLite SET SettingValue = N'{0}' WHERE SettingKey = N'LastBlobModification'", currentTimestamp.ToString(m_CurrentEnCulture))
                };
                cmd.ExecuteNonQuery();
            }
        }
    }
}

