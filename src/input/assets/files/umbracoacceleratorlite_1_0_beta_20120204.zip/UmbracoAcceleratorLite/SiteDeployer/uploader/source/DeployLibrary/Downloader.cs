﻿// UmbracoAcceleratorLite is based on the Windows Azure Accelerator for Umbraco
// project by Microsoft. Original project: http://waacceleratorumbraco.codeplex.com/
//
// Copyright (C) 2012 Gianni Rosa Gallina. All rights reserved.
//
// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

namespace DeployLibrary
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using Microsoft.WindowsAzure;
    using Microsoft.WindowsAzure.StorageClient;

    // UmbracoAcceleratorLite
    public class Downloader
    {
        private const string AzureAcceleratorFileName = "UmbracoAcceleratorLite";
        private Dictionary<string, Entry> m_Entries;
        private Dictionary<string, Entry> m_BlobEntries;
        private readonly HashSet<string> m_PatternToBeIgnored;
        private readonly CloudBlobContainer m_Container;
        private readonly DateTime m_LastSyncDate;

        private readonly string hostName;
        private readonly string pathToUpload;
        private readonly string storageAccountName;
        private readonly string storageAccountKey;
        private readonly string containerName;

        public Downloader(string hostName, string pathToUpload, string storageAccountName, string storageAccountKey, string containerName, string ignorePatterns, DateTime lastSyncDate)
        {
            this.hostName = hostName;
            this.pathToUpload = pathToUpload;
            this.storageAccountName = storageAccountName;
            this.storageAccountKey = storageAccountKey;
            this.containerName = containerName;

            m_LastSyncDate = lastSyncDate;

            m_Container = GetContainer();
            m_PatternToBeIgnored = new HashSet<string>();
            string[] patternToIgnore = ignorePatterns.Split(' ');
            foreach (string p in patternToIgnore)
            {
                m_PatternToBeIgnored.Add(p.ToLower());
            }
        }

        public delegate void MessageHandler(string message, long size);

        public delegate void DeleteBlobHandler(string message);

        public delegate void CountHandler(int count, long totalSize);

        public event MessageHandler DownloadFile;

        public event DeleteBlobHandler DeleteFile;

        public event MessageHandler CreateDirectory;

        public bool Stopped { get; set; }

        public void Run(bool sync)
        {
            var seen = new HashSet<string>();

            foreach (var entry in m_BlobEntries)
            {
                if (Stopped)
                {
                    break;
                }

                if (entry.Key == hostName)
                {
                    continue;
                }

                string path = entry.Key.Substring(hostName.Length + 1);
                if (!entry.Value.IsDirectory)
                {
                    string entryFolder = Path.GetDirectoryName(path).Replace('\\', '/');
                    if (!seen.Contains(entryFolder))
                    {
                        seen.Add(entryFolder);
                    }
                }
                seen.Add(path);

                if (!m_Entries.ContainsKey(path) || m_Entries[path].LocalLastModified > m_LastSyncDate || m_LastSyncDate < entry.Value.CloudLastModified)
                {
                    if (entry.Value.IsDirectory)
                    {
                        if (CreateDirectory != null)
                        {
                            CreateDirectory(path, 0);
                        }

                        Directory.CreateDirectory(Path.Combine(pathToUpload, path));
                    }
                    else
                    {
                        if (DownloadFile != null)
                        {
                            int pos = path.IndexOf('/');
                            string name = path;

                            if (pos > 0)
                            {
                                name = path.Substring(pos + 1);
                            }

                            DownloadFile(name, entry.Value.Length);
                        }

                        Directory.CreateDirectory(Path.Combine(pathToUpload, Path.GetDirectoryName(path)));

                        using (FileStream stream = File.Open(Path.Combine(pathToUpload, path), FileMode.Create, FileAccess.Write, FileShare.ReadWrite | FileShare.Delete))
                        {
                            entry.Value.BlobReference.DownloadToStream(stream);
                        }
                    }

                    entry.Value.LocalLastModified = new FileInfo(Path.Combine(pathToUpload, path)).LastWriteTimeUtc;
                    m_Entries[path] = entry.Value;
                }
            }

            if (sync)
            {
                foreach (string path in m_Entries.Keys.Where(k => !seen.Contains(k)).ToArray())
                {
                    if (!m_Entries.ContainsKey(path))
                    {
                        // Already NOT existing, so no delete required
                        continue;
                    }

                    if (m_Entries[path].IsDirectory)
                    {
                        if (!Directory.EnumerateFileSystemEntries(Path.Combine(pathToUpload, path)).Any())
                        {
                            try
                            {
                                Directory.Delete(Path.Combine(pathToUpload, path), true);
                            }
                            catch
                            {
                            }
                        }
                    }
                    else
                    {
                        try
                        {
                            File.Delete(Path.Combine(pathToUpload, path));
                        }
                        catch
                        {
                        }
                    }

                    m_Entries.Remove(path);
                }
            }
        }

        private bool HastToBeIgnored(string pattern)
        {
            return m_PatternToBeIgnored.Any(pattern.Contains);
        }

        public void Stop()
        {
            Stopped = true;
        }

        public ICollection<string> GetCurrentLocalEntries()
        {
            m_Entries = new Dictionary<string, Entry>();
            IList<string> files = new List<string>();
            List<Tuple<string, Entry>> localEntries = EnumerateEntries(pathToUpload).ToList();
            foreach (var localEntry in localEntries)
            {
                string path = localEntry.Item1;
                Entry entry = localEntry.Item2;
                files.Add(path);
                if (!m_Entries.ContainsKey(path) || m_Entries[path].LocalLastModified < entry.LocalLastModified)
                {
                    m_Entries[path] = entry;
                }
            }
            return files;
        }

        public ICollection<string> GetCurrentBlobs()
        {
            m_BlobEntries = new Dictionary<string, Entry>();

            CloudBlobContainer container = m_Container;

            int prefixLength = container.Uri.ToString().Length;
            IList<string> blobs = new List<string>();

            List<CloudBlob> cloudBlobs = container.ListBlobs(new BlobRequestOptions {
                UseFlatBlobListing = true,
                BlobListingDetails = BlobListingDetails.Metadata
            }).OfType<CloudBlob>().ToList();

            foreach (CloudBlob blob in cloudBlobs)
            {
                string path = blob.Uri.ToString().Substring(prefixLength + 1);

                if (path.Equals(hostName, StringComparison.OrdinalIgnoreCase) || path.StartsWith(String.Format("{0}/", hostName), StringComparison.OrdinalIgnoreCase))
                {
                    blobs.Add(path);

                    var entry = new Entry {
                        Length = blob.Properties.Length,
                        IsDirectory = blob.Metadata["IsDirectory"] == "true",
                        CloudLastModified = blob.Properties.LastModifiedUtc,
                        SiteName = path.Split('/').First(),
                        BlobReference = blob
                    };

                    if (!m_BlobEntries.ContainsKey(path) || m_BlobEntries[path].CloudLastModified < entry.CloudLastModified)
                    {
                        m_BlobEntries[path] = entry;
                    }
                }
            }

            return blobs;
        }

        public void DeleteCurrentFiles()
        {
            foreach (var localEntry in EnumerateEntries(pathToUpload))
            {
                try
                {
                    if (Directory.Exists(pathToUpload))
                    {
                        Directory.Delete(pathToUpload, true);
                    }
                    m_Entries.Clear();

                    Directory.CreateDirectory(pathToUpload);
                }
                catch
                {
                    // Ignore delete error
                }
            }
        }

        public long GetTotalSizeToDownload()
        {
            long totalSize = 0;
            if (m_BlobEntries != null)
            {
                totalSize = m_BlobEntries.Sum(t => t.Value.Length);
            }

            return totalSize;
        }

        private IEnumerable<Tuple<string, Entry>> EnumerateEntries(string path)
        {
            foreach (string directory in Directory.EnumerateFileSystemEntries(path, "*", SearchOption.AllDirectories))
            {
                string relativePath = directory.Substring(path.Length + 1).Replace('\\', '/');

                // Ignore app_data content, obj/ content, AzureAcceleratorEx files and user-specified file extensions
                string relativePathLower = relativePath.ToLowerInvariant();
                if (relativePathLower.StartsWith(@"app_data") || relativePathLower.StartsWith(@"obj/") || relativePath.Contains(AzureAcceleratorFileName) || HastToBeIgnored(relativePathLower))
                {
                    continue;
                }

                var info = new FileInfo(directory);
                var entry = new Entry {
                    LocalLastModified = info.LastWriteTimeUtc,
                    IsDirectory = info.Attributes.HasFlag(FileAttributes.Directory),
                    Length = info.Attributes.HasFlag(FileAttributes.Directory) ? 0 : info.Length,
                    SiteName = hostName
                };

                yield return new Tuple<string, Entry>(relativePath, entry);
            }
        }

        private CloudBlobContainer GetContainer()
        {
            CloudStorageAccount account;

            if (storageAccountKey == null)
            {
                account = CloudStorageAccount.DevelopmentStorageAccount;
            }
            else
            {
                string storageConnectionString = string.Format("DefaultEndpointsProtocol=https;AccountName={0};AccountKey={1}", storageAccountName, storageAccountKey);
                account = CloudStorageAccount.Parse(storageConnectionString);
            }

            CloudBlobContainer container = account.CreateCloudBlobClient().GetContainerReference(containerName);
            container.CreateIfNotExist();

            return container;
        }
    }
}

