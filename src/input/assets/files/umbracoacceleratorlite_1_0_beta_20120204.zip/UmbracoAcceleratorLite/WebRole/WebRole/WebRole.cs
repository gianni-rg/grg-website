﻿// UmbracoAcceleratorLite is based on the Windows Azure Accelerator for Umbraco
// project by Microsoft. Original project: http://waacceleratorumbraco.codeplex.com/
//
// Copyright (C) 2012 Gianni Rosa Gallina. All rights reserved.
//
// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

namespace Microsoft.Samples.UmbracoAccelerator
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Security.AccessControl;
    using System.Security.Cryptography.X509Certificates;
    using System.Text.RegularExpressions;
    using System.Threading;
    using System.Xml.Linq;
    using Sites;
    using Web.Administration;
    using WindowsAzure;
    using WindowsAzure.ServiceRuntime;
    using WindowsAzure.StorageClient;

    public class Entry
    {
        public DateTime LocalLastModified { get; set; }

        public DateTime CloudLastModified { get; set; }

        public bool IsDirectory { get; set; }

        public string SiteName { get; set; }
    }

    public class Site
    {
        public DateTime LocalLastModified { get; set; }

        public DateTime CloudLastModified { get; set; }

        public string ConnectionString { get; set; }

        public string Name { get; set; }
    }

    public class WebRole : RoleEntryPoint
    {
        private string m_LocalPath;
        private CloudBlobContainer m_Container;
        private Dictionary<string, Entry> m_Entries;
        private HashSet<string> m_Mappings;
        private IEnumerable<string> m_DirectoriesToExclude;
        private CultureInfo m_CurrentEnCulture;

        private const string AzureAcceleratorFileName = "UmbracoAcceleratorLite";
        private readonly string m_LocalAzureAcceleratorFileName = String.Format("{0}.local", AzureAcceleratorFileName);

        private double m_SyncInterval;
        private Dictionary<string, Site> m_MonitoredSites;

        public override void Run()
        {
            SyncForever(TimeSpan.FromSeconds(m_SyncInterval));
        }

        public override bool OnStart()
        {
            RoleEnvironment.Changing += (_, e) =>
            {
                if (e.Changes.Any(c => c is RoleEnvironmentConfigurationSettingChange))
                {
                    e.Cancel = true;
                }
            };

            m_LocalPath = RoleEnvironment.GetLocalResource("Sites").RootPath.TrimEnd('\\');
            m_DirectoriesToExclude = RoleEnvironment.GetConfigurationSettingValue("DirectoriesToExclude").Split(';');

            m_SyncInterval = Convert.ToDouble(RoleEnvironment.GetConfigurationSettingValue("SyncInterval"));

            DirectorySecurity sec = Directory.GetAccessControl(m_LocalPath);
            sec.AddAccessRule(new FileSystemAccessRule("Everyone", FileSystemRights.FullControl, InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit, PropagationFlags.None, AccessControlType.Allow));
            Directory.SetAccessControl(m_LocalPath, sec);

            string localdata = RoleEnvironment.GetLocalResource("LocalData").RootPath.TrimEnd('\\');

            DirectorySecurity secdata = Directory.GetAccessControl(localdata);
            secdata.AddAccessRule(new FileSystemAccessRule("Everyone", FileSystemRights.FullControl, InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit, PropagationFlags.None, AccessControlType.Allow));
            Directory.SetAccessControl(localdata, secdata);

            m_Container = CloudStorageAccount.Parse(RoleEnvironment.GetConfigurationSettingValue("DataConnectionString")).CreateCloudBlobClient().GetContainerReference(RoleEnvironment.GetConfigurationSettingValue("SitesContainerName"));
            m_Container.CreateIfNotExist();
            m_Entries = new Dictionary<string, Entry>();
            m_Mappings = new HashSet<string>();

            m_MonitoredSites = new Dictionary<string, Site>();

            m_CurrentEnCulture = CultureInfo.CreateSpecificCulture("en-US");

            Sync(true);

            return base.OnStart();
        }

        #region Private methods
        private void SyncForever(TimeSpan interval)
        {
            while (true)
            {
                try
                {
                    Sync(false);
                }
                catch (Exception e)
                {
                    // log all exceptions to blobs
                    CloudBlobContainer errors = CloudStorageAccount.Parse(RoleEnvironment.GetConfigurationSettingValue("DataConnectionString")).CreateCloudBlobClient().GetContainerReference("errors");
                    errors.CreateIfNotExist();
                    CloudBlob error = errors.GetBlobReference((DateTime.MaxValue - DateTime.UtcNow).Ticks.ToString("d19") + ".txt");
                    error.Properties.ContentType = "text/plain";
                    error.UploadText(e.ToString());
                }

                Thread.Sleep(interval);
            }
        }

        private void Sync(bool onStart)
        {
            var umbracoSettings = new HashSet<string>();
            var seen = new HashSet<string>();
            var newCerts = new HashSet<string>();
            var sitesToBeSync = new HashSet<string>();
            var sitesUpdated = new HashSet<string>();

            // Retrieves all web.config files present in "sites".
            // For each of them, retrieve each site's DB connection string.
            RetrieveLocalWebsites();

            #region Syncronization process - LOCAL --> BLOB STORAGE
            // Retrieves all UmbracoAcceleratorLite.local files present in "sites".
            // For each of them, compiles a list of sites to be synchronized.
            bool updateCloudTimestamp = false;
            string[] sitesSyncFiles = Directory.GetFiles(m_LocalPath, m_LocalAzureAcceleratorFileName, SearchOption.AllDirectories);
            foreach (string siteSyncFile in sitesSyncFiles)
            {
                string relativePath = siteSyncFile.Substring(m_LocalPath.Length + 1).Replace('\\', '/');
                string siteName = relativePath.Split('/').First();

                var info = new FileInfo(siteSyncFile);

                var site = new Site {
                    Name = siteName,
                    LocalLastModified = info.LastWriteTimeUtc,
                };

                if (!m_MonitoredSites.ContainsKey(siteName) || m_MonitoredSites[siteName].LocalLastModified < site.LocalLastModified)
                {
                    if (!m_MonitoredSites.ContainsKey(siteName))
                    {
                        m_MonitoredSites.Add(siteName, site);
                    }
                    else
                    {
                        m_MonitoredSites[siteName].LocalLastModified = site.LocalLastModified;
                    }
                    sitesToBeSync.Add(siteName);
                }

                try
                {
                    File.Delete(siteSyncFile);
                }
                catch
                {
                }
            }

            foreach (var thing in EnumerateLocalEntries())
            {
                string path = thing.Item1;
                Entry entry = thing.Item2;

                // Check if the current entry is part of a site to be synchronized.
                // If so, the original UmbracoAccelerator behavior is performed. 
                // If not, just continue with the next entry.
                bool entryToProcess = sitesToBeSync.Contains(entry.SiteName);

                // Mark the entry as "still existing". If an entry is not added to the set,
                // it means that it has been deleted locally. Later, it will be deleted on the
                // blob storage.
                seen.Add(path);

                // Don't sync any directory and "AzureAccelerator.xxx files"
                if (!entryToProcess || entry.IsDirectory || path.Contains(AzureAcceleratorFileName))
                {
                    continue;
                }

                string fileNameToLower = Path.GetFileName(path).ToLowerInvariant();
                if (fileNameToLower == "umbracosettings.config")
                {
                    umbracoSettings.Add(path);
                }

                if (!m_Entries.ContainsKey(path) || m_Entries[path].LocalLastModified < entry.LocalLastModified)
                {
                    CloudBlob newBlob = m_Container.GetBlobReference(path);
                    if (entry.IsDirectory)
                    {
                        newBlob.Metadata["IsDirectory"] = "true";
                        newBlob.UploadByteArray(new byte[0]);
                        sitesUpdated.Add(entry.SiteName);
                    }
                    else if (fileNameToLower != "umbraco.config")
                    {
                        // ignore umbraco.config
                        using (FileStream stream = File.Open(Path.Combine(m_LocalPath, path), FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
                        {
                            newBlob.UploadFromStream(stream);
                            sitesUpdated.Add(entry.SiteName);
                        }
                    }

                    entry.CloudLastModified = newBlob.Properties.LastModifiedUtc;
                    m_Entries[path] = entry;
                    updateCloudTimestamp = true;
                }
            }

            // For each local deleted files, delete it on the blob storage
            foreach (var entry in m_Entries.Where(k => !seen.Contains(k.Key)).ToArray())
            {
                if (string.IsNullOrEmpty(Path.GetDirectoryName(entry.Key)) && Path.GetExtension(entry.Key).ToLowerInvariant() == ".pfx")
                {
                    // leave these alone
                    continue;
                }

                try
                {
                    m_Container.GetBlobReference(entry.Key).Delete();
                    sitesUpdated.Add(entry.Value.SiteName);
                    updateCloudTimestamp = true;
                }
                catch
                {
                    // ignore if the blob's already gone
                }

                m_Entries.Remove(entry.Key);
            }
            #endregion

            #region Syncronization process - BLOB STORAGE --> LOCAL
            // If it is the first time sync, called by OnStart():
            // - execute a full sync
            //
            // If it is a normal sync:
            // - Check in the UmbracoDB/UmbracoAcceleratorLite table for the latest blob modification timestamp and
            //   compare it with the local latest modification timestamp.
            // - If a sync is not required, avoid accessing the blob storage and perform sync operation.
            // - If it does, retrieve blob listing and sync files (comparing their latest modification date).

            bool executeSync = false;
            if (!onStart)
            {
                foreach (string site in m_MonitoredSites.Keys)
                {
                    DateTime lastBlobModification = GetLastBlobModification(site);

                    if (m_MonitoredSites[site].CloudLastModified < lastBlobModification)
                    {
                        executeSync = true;
                        m_MonitoredSites[site].CloudLastModified = lastBlobModification;
                    }
                }
            }

            if (onStart || executeSync)
            {
                seen = new HashSet<string>();

                List<CloudBlob> blobs = m_Container.ListBlobs(new BlobRequestOptions {
                    UseFlatBlobListing = true,
                    BlobListingDetails = BlobListingDetails.Metadata
                }).OfType<CloudBlob>().ToList();

                foreach (CloudBlob blob in blobs)
                {
                    string path = blob.Uri.ToString().Substring(m_Container.Uri.ToString().Length + 1);
                    var entry = new Entry {
                        IsDirectory = blob.Metadata["IsDirectory"] == "true",
                        CloudLastModified = blob.Properties.LastModifiedUtc,
                        SiteName = path.Split('/').First()
                    };

                    seen.Add(path);

                    if (!m_Entries.ContainsKey(path) || m_Entries[path].CloudLastModified < entry.CloudLastModified)
                    {
                        if (entry.IsDirectory)
                        {
                            Directory.CreateDirectory(Path.Combine(m_LocalPath, path));
                        }
                        else if (string.IsNullOrEmpty(Path.GetDirectoryName(path)) && Path.GetExtension(path).ToLowerInvariant() == ".pfx")
                        {
                            newCerts.Add(Path.GetFileNameWithoutExtension(path).ToLowerInvariant());

                            // don't actually download this, no need to have the cert sitting around on disk
                            m_Entries[path] = entry;
                        }
                        else
                        {
                            // ignore umbraco.config
                            if (Path.GetFileName(path).ToLowerInvariant() != "umbraco.config")
                            {
                                Directory.CreateDirectory(Path.Combine(m_LocalPath, Path.GetDirectoryName(path)));

                                using (FileStream stream = File.Open(Path.Combine(m_LocalPath, path), FileMode.Create, FileAccess.Write, FileShare.ReadWrite | FileShare.Delete))
                                {
                                    blob.DownloadToStream(stream);
                                }
                            }
                        }

                        entry.LocalLastModified = new FileInfo(Path.Combine(m_LocalPath, path)).LastWriteTimeUtc;
                        m_Entries[path] = entry;
                    }
                }

                foreach (string path in m_Entries.Keys.Where(k => !seen.Contains(k) && Path.GetFileName(k).ToLowerInvariant() != "umbraco.config").ToArray())
                {
                    if (!m_Entries.ContainsKey(path))
                    {
                        // Already NOT existing, so no delete required
                        continue;
                    }

                    if (m_Entries[path].IsDirectory)
                    {
                        try
                        {
                            Directory.Delete(Path.Combine(m_LocalPath, path), true);
                        }
                        catch
                        {
                        }
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(Path.GetDirectoryName(path)) && Path.GetExtension(path).ToLowerInvariant() == ".pfx")
                        {
                            newCerts.Add(Path.GetFileNameWithoutExtension(path).ToLowerInvariant());
                        }

                        try
                        {
                            File.Delete(Path.Combine(m_LocalPath, path));
                        }
                        catch
                        {
                        }
                    }

                    m_Entries.Remove(path);
                }
            }
            #endregion

            // Update last sync timestamp for each updated site
            if (updateCloudTimestamp)
            {
                foreach (string site in sitesUpdated)
                {
                    UpdateCloudLastModification(site);
                }
            }

            if(onStart)
            {
                RetrieveLocalWebsites();
                foreach (var site in m_MonitoredSites)
                {
                    site.Value.CloudLastModified = GetLastBlobModification(site.Key);
                }
            }

            #region IIS Site mappings
            var newMappings = new HashSet<string>();
            foreach (string site in Directory.EnumerateDirectories(m_LocalPath).Select(d => Path.GetFileName(d).ToLowerInvariant()))
            {
                foreach (RoleInstance instance in RoleEnvironment.CurrentRoleInstance.Role.Instances)
                {
                    newMappings.Add(string.Format(CultureInfo.InvariantCulture, "{0} {1}.{2}", instance.InstanceEndpoints["UnusedInternal"].IPEndpoint.Address, Regex.Match(instance.Id, @"\d+$").Value, site));
                }
            }

            if (!newMappings.SetEquals(m_Mappings))
            {
                string hostsFile = Environment.ExpandEnvironmentVariables(@"%windir%\system32\drivers\etc\hosts");
                File.Delete(hostsFile);
                File.WriteAllLines(hostsFile, newMappings);
                m_Mappings = newMappings;
            }

            foreach (string path in umbracoSettings)
            {
                try
                {
                    string siteName = path.Split('/').First();
                    string fileName = Path.Combine(m_LocalPath, path);
                    XDocument doc = XDocument.Load(fileName);
                    XElement dc = doc.Root.Element("distributedCall");
                    dc.Attribute("enable").Value = "true";
                    XElement servers = dc.Element("servers");
                    var oldServers = new HashSet<string>(servers.Elements("server").Select(e => e.Value));
                    var newServers = new HashSet<string>(RoleEnvironment.CurrentRoleInstance.Role.Instances.Select(i => Regex.Match(i.Id, @"\d+$").Value + "." + siteName));

                    if (!oldServers.SetEquals(newServers))
                    {
                        servers.RemoveAll();
                        foreach (string address in newServers)
                        {
                            servers.Add(new XElement("server", new XText(address)));
                        }

                        doc.Save(fileName);
                    }
                }
                catch
                {
                    // likely because the file no longer exists (this happens if one gets deleted)... no big deal no matter what the error is
                }
            }

            UpdateSites(newCerts);
            #endregion
        }

        private void RetrieveLocalWebsites()
        {
            string[] webConfigFiles = Directory.GetFiles(m_LocalPath, "web.config", SearchOption.AllDirectories);
            foreach (string webConfigFile in webConfigFiles)
            {
                string relativePath = webConfigFile.Substring(m_LocalPath.Length + 1).Replace('\\', '/');
                string siteName = relativePath.Split('/').First();

                XElement webConfig = XElement.Load(webConfigFile);
                string connectionString = (from setting in webConfig.Descendants("appSettings") where setting.Element("add").Attribute("key").Value == "umbracoDbDSN" select setting.Element("add").Attribute("value").Value).FirstOrDefault();
                if (!string.IsNullOrEmpty(connectionString))
                {
                    if (!m_MonitoredSites.ContainsKey(siteName))
                    {
                        var site = new Site {
                            Name = siteName,
                            ConnectionString = connectionString,
                        };
                        m_MonitoredSites.Add(siteName, site);
                    }
                    else
                    {
                        m_MonitoredSites[siteName].ConnectionString = connectionString;
                    }
                }
            }
        }

        private IEnumerable<Tuple<string, Entry>> EnumerateLocalEntries()
        {
            foreach (string directory in Directory.EnumerateFileSystemEntries(m_LocalPath, "*", SearchOption.AllDirectories))
            {
                string relativePath = directory.Substring(m_LocalPath.Length + 1).Replace('\\', '/');
                var info = new FileInfo(directory);

                string siteName = relativePath.Split('/').First();

                var entry = new Entry {
                    LocalLastModified = info.LastWriteTimeUtc,
                    IsDirectory = info.Attributes.HasFlag(FileAttributes.Directory),
                    SiteName = siteName
                };

                if (IsExcluded(relativePath))
                {
                    continue;
                }

                yield return new Tuple<string, Entry>(relativePath, entry);
            }
        }

        private bool IsExcluded(string topPath)
        {
            int position = topPath.IndexOf('/');

            if (position <= 0)
            {
                return false;
            }

            // Remove Site name
            string path = topPath.Substring(position + 1);

            if (m_DirectoriesToExclude.Contains(path, StringComparer.OrdinalIgnoreCase))
            {
                return true;
            }

            foreach (string toexclude in m_DirectoriesToExclude)
            {
                if (path.StartsWith(toexclude + "/"))
                {
                    return true;
                }
            }

            return false;
        }

        private void UpdateSites(IEnumerable<string> newCerts)
        {
            var sitesToAdd = new Dictionary<string, string>();

            foreach (string hostToAdd in Directory.EnumerateDirectories(m_LocalPath).Select(d => Path.GetFileName(d).ToLowerInvariant()))
            {
                sitesToAdd[hostToAdd.Replace('.', '-')] = hostToAdd;
            }

            using (var serverManager = new ServerManager())
            {
                foreach (string newCert in newCerts)
                {
                    // remove each of these so we reprocess them with an SSL binding
                    try
                    {
                        Web.Administration.Site s = serverManager.Sites[RoleEnvironment.CurrentRoleInstance.Id + "_" + newCert.Replace('.', '-')];
                        serverManager.Sites.Remove(s);

                        string appPoolName = s.Name;
                        ApplicationPool appPool = serverManager.ApplicationPools.SingleOrDefault(ap => ap.Name.Equals(appPoolName, StringComparison.OrdinalIgnoreCase));
                        if (appPool != null)
                        {
                            serverManager.ApplicationPools.Remove(appPool);
                        }
                    }
                    catch
                    {
                        // ignore if the site doesn't exist
                    }
                }

                var sitestosave = new List<string>();

                foreach (Web.Administration.Site site in serverManager.Sites.Where(s => s.Name.StartsWith(RoleEnvironment.CurrentRoleInstance.Id, StringComparison.OrdinalIgnoreCase)).ToArray())
                {
                    string name = site.Name.Substring(RoleEnvironment.CurrentRoleInstance.Id.Length + 1).ToLowerInvariant();

                    // never delete "Web," which is the website for this web role
                    if (!sitesToAdd.Remove(name) && name != "web")
                    {
                        serverManager.Sites.Remove(site);

                        // Remove appPool
                        string appPoolName = site.Name;
                        ApplicationPool appPool = serverManager.ApplicationPools.SingleOrDefault(ap => ap.Name.Equals(appPoolName, StringComparison.OrdinalIgnoreCase));
                        if (appPool != null)
                        {
                            serverManager.ApplicationPools.Remove(appPool);
                        }
                    }
                    else
                    {
                        sitestosave.Add(name.Replace('-', '.'));
                    }
                }

                SaveSites(sitestosave.ToArray());

                foreach (var site in sitesToAdd)
                {
                    // default binding is just the site name (example.org)
                    Web.Administration.Site newSite = serverManager.Sites.Add(RoleEnvironment.CurrentRoleInstance.Id + "_" + site.Key, "http", RoleEnvironment.CurrentRoleInstance.InstanceEndpoints["HttpIn"].IPEndpoint + ":" + site.Value, Path.Combine(m_LocalPath, site.Value));

                    // Create application pool
                    string appPoolName = newSite.Name;
                    ApplicationPool appPool = serverManager.ApplicationPools.SingleOrDefault(ap => ap.Name.Equals(appPoolName, StringComparison.OrdinalIgnoreCase));
                    if (appPool == null)
                    {
                        appPool = serverManager.ApplicationPools.Add(appPoolName);
                        appPool.ManagedRuntimeVersion = "v4.0";
                        appPool.ProcessModel.IdentityType = ProcessModelIdentityType.NetworkService;
                    }

                    newSite.ApplicationDefaults.ApplicationPoolName = appPool.Name;

                    // second binding is (n.example.org), where n is the number in the instance ID
                    string n = Regex.Match(RoleEnvironment.CurrentRoleInstance.Id, @"\d+$").Value;
                    newSite.Bindings.Add(RoleEnvironment.CurrentRoleInstance.InstanceEndpoints["HttpIn"].IPEndpoint + ":" + n + "." + site.Value, "http");

                    // third binding is SSL (if applicable)
                    X509Certificate2 cert = null;
                    try
                    {
                        byte[] rawData = m_Container.GetBlobReference(site.Value + ".pfx").DownloadByteArray();
                        string password = m_Container.GetBlobReference(site.Value + ".pfx.txt").DownloadText();

                        cert = new X509Certificate2(rawData, password);
                    }
                    catch
                    {
                        // ignore if blob is missing or invalid
                    }

                    if (cert != null)
                    {
                        var store = new X509Store(StoreName.My, StoreLocation.LocalMachine);
                        store.Open(OpenFlags.ReadWrite);
                        store.Add(cert);
                        newSite.Bindings.Add(RoleEnvironment.CurrentRoleInstance.InstanceEndpoints["HttpsIn"].IPEndpoint + ":" + site.Value, cert.GetCertHash(), StoreName.My.ToString());
                    }
                }

                try
                {
                    serverManager.CommitChanges();
                }
                catch
                {
                }
            }
        }

        private void SaveSites(string[] sites)
        {
            string path = RoleEnvironment.GetLocalResource("LocalData").RootPath.TrimEnd('\\');
            Directory.CreateDirectory(path);
            string filename = Path.Combine(path, "Sites.txt");

            var infosites = new Dictionary<string, SiteInfo>();

            foreach (string key in m_Entries.Keys)
            {
                Entry entry = m_Entries[key];
                string domain;

                int pos = key.IndexOf('/');

                if (pos > 0)
                {
                    domain = key.Substring(0, key.IndexOf('/'));
                }
                else
                {
                    domain = key;
                }

                if (sites.Contains(domain))
                {
                    if (!infosites.ContainsKey(domain))
                    {
                        infosites[domain] = new SiteInfo {
                            Name = domain,
                            LastCloudDateTime = entry.CloudLastModified,
                            NoFiles = 1
                        };
                    }
                    else
                    {
                        infosites[domain].NoFiles++;
                        if (infosites[domain].LastCloudDateTime < entry.CloudLastModified)
                        {
                            infosites[domain].LastCloudDateTime = entry.CloudLastModified;
                        }
                    }
                }
            }

            var newsites = new string[infosites.Keys.Count];
            int nsite = 0;

            foreach (SiteInfo info in infosites.Values)
            {
                newsites[nsite++] = string.Format("{0}|{1}|{2}", info.Name, info.LastCloudDateTime, info.NoFiles);
            }

            if (File.Exists(filename))
            {
                string[] oldsites = File.ReadAllLines(filename);

                if (oldsites.Length == newsites.Length)
                {
                    int k;
                    for (k = 0; k < oldsites.Length; k++)
                    {
                        if (oldsites[k] != newsites[k])
                        {
                            break;
                        }
                    }

                    if (k >= oldsites.Length)
                    {
                        return;
                    }
                }
            }

            File.WriteAllLines(filename, newsites);
        }

        private DateTime GetLastBlobModification(string site)
        {
            DateTime lastBlobModification = DateTime.MinValue;
            using (var cn = new SqlConnection(m_MonitoredSites[site].ConnectionString))
            {
                cn.Open();

                var cmd = new SqlCommand {
                    Connection = cn,
                    CommandText = "SELECT * FROM UmbracoAcceleratorLite"
                };
                IDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    if (reader[0].ToString() == "LastBlobModification")
                    {
                        DateTime tempDate;
                        if (DateTime.TryParse(reader[1].ToString(), m_CurrentEnCulture, DateTimeStyles.None, out tempDate))
                        {
                            lastBlobModification = tempDate;
                        }
                    }
                }
            }
            return lastBlobModification;
        }

        private void UpdateCloudLastModification(string site)
        {
            if (!m_MonitoredSites.ContainsKey(site))
            {
                return;
            }

            DateTime currentTimestamp = DateTime.UtcNow;
            using (var cn = new SqlConnection(m_MonitoredSites[site].ConnectionString))
            {
                cn.Open();

                var cmd = new SqlCommand {
                    Connection = cn,
                    CommandText = String.Format("UPDATE UmbracoAcceleratorLite SET SettingValue = N'{0}' WHERE SettingKey = N'LastBlobModification'", currentTimestamp.ToString(m_CurrentEnCulture))
                };
                cmd.ExecuteNonQuery();
            }
            m_MonitoredSites[site].CloudLastModified = currentTimestamp;
        }
        #endregion
    }
}