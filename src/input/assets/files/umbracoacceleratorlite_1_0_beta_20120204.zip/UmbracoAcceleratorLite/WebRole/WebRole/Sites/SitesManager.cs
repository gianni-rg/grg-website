﻿// UmbracoAcceleratorLite is based on the Windows Azure Accelerator for Umbraco
// project by Microsoft. Original project: http://waacceleratorumbraco.codeplex.com/
//
// Copyright (C) 2012 Gianni Rosa Gallina. All rights reserved.
//
// ----------------------------------------------------------------------------------
// Microsoft Developer & Platform Evangelism
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
// ----------------------------------------------------------------------------------
// The example companies, organizations, products, domain names,
// e-mail addresses, logos, people, places, and events depicted
// herein are fictitious.  No association with any real company,
// organization, product, domain name, email address, logo, person,
// places, or events is intended or should be inferred.
// ----------------------------------------------------------------------------------

namespace Microsoft.Samples.UmbracoAccelerator.Sites
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using WindowsAzure;
    using WindowsAzure.ServiceRuntime;
    using WindowsAzure.StorageClient;

    public class SitesManager
    {
        private readonly string localPath;

        public SitesManager(string localPath)
        {
            this.localPath = localPath;
        }

        public IEnumerable<SiteInfo> GetSitesInformation()
        {
            var sites = new List<SiteInfo>();

            try
            {
                string path = RoleEnvironment.GetLocalResource("LocalData").RootPath.TrimEnd('\\');
                string filename = Path.Combine(path, "Sites.txt");
                string[] serversites = File.ReadAllLines(filename);

                foreach (string serversite in serversites)
                {
                    SiteInfo site = sites.Where(s => s.Name.Equals(serversite, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
                    if (site != null)
                    {
                        site.IsWebSite = true;
                    }
                }

                foreach (string serversite in serversites)
                {
                    string[] data = serversite.Split('|');
                    sites.Add(new SiteInfo {
                        Name = data[0],
                        LastCloudDateTime = DateTime.Parse(data[1]),
                        NoFiles = int.Parse(data[2])
                    });
                }
            }
            catch (Exception e)
            {
                CloudBlobContainer errors;
                if (RoleEnvironment.IsEmulated)
                {
                    errors = CloudStorageAccount.Parse("UseDevelopmentStorage=true").CreateCloudBlobClient().GetContainerReference("errors");
                }
                else
                {
                    errors = CloudStorageAccount.Parse(RoleEnvironment.GetConfigurationSettingValue("DataConnectionString")).CreateCloudBlobClient().GetContainerReference("errors");
                }
                //var errors = CloudStorageAccount.Parse(RoleEnvironment.GetConfigurationSettingValue("DataConnectionString")).CreateCloudBlobClient().GetContainerReference("errors");
                errors.CreateIfNotExist();
                var error = errors.GetBlobReference((DateTime.MaxValue - DateTime.UtcNow).Ticks.ToString("d19") + ".txt");
                error.Properties.ContentType = "text/plain";
                error.UploadText(e.ToString());
            }

            return sites;
        }

        private IEnumerable<FileInfo> EnumerateFiles(string path)
        {
            foreach (string item in Directory.EnumerateFileSystemEntries(path, "*", SearchOption.AllDirectories))
            {
                string relativePath = item.Substring(localPath.Length + 1).Replace('\\', '/');
                var info = new FileInfo(item);

                yield return info;
            }
        }
    }
}